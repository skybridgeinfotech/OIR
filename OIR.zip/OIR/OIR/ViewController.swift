//
//  ViewController.swift
//  OIR
//
//  Created by SRIHARISKYLAP0022 on 21/02/18.
//  Copyright © 2018 Skybridgeinfotech. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Dashboard"
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.barTintColor = UIColor(red: 218/255, green: 33/255, blue: 39/255, alpha: 1)
        self.navigationController?.navigationBar.tintColor = UIColor(red: 218/255, green: 33/255, blue: 39/255, alpha: 1)
        self.navigationController!.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

